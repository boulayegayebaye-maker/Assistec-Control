# ASSISTEC — Contrôle Technique

Application de contrôle technique avec analyse IA — 594 points de vérification / 8 lots techniques.

## Fichiers du projet

```
assistec-controle/
├── app.py                  ← Serveur Python (Flask)
├── requirements.txt        ← Dépendances Python
├── render.yaml             ← Configuration Render.com
├── app_assistec_v4.html    ← Application frontend
├── matrice.js              ← Base de données des 594 points
├── sw.js                   ← Service Worker (PWA offline)
├── manifest.json           ← Manifeste PWA
└── README.md               ← Ce fichier
```

## Déploiement sur Render.com

1. Pusher tous ces fichiers sur GitHub
2. Sur Render.com → New → Web Service → connecter le dépôt GitHub
3. Render détecte automatiquement Python et déploie
4. URL fournie par Render : https://assistec-controle.onrender.com

## Mise à jour de la matrice

1. Générer le nouveau matrice.js (avec Claude)
2. Remplacer matrice.js sur GitHub
3. Mettre à jour MATRICE_VERSION dans app.py
4. Render redéploie automatiquement en 2 minutes
5. Tous les utilisateurs voient la nouvelle version à la prochaine ouverture

## API disponible

- GET /              → Application principale
- GET /api/version   → Version et statistiques de la matrice
- GET /health        → Santé du serveur
- GET /matrice.js    → Base de données des points de contrôle
